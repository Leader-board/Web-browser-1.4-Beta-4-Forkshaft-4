﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class newribbon
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.QRibbon1 = New Qios.DevSuite.Components.Ribbon.QRibbon()
        CType(Me.QRibbon1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'QRibbon1
        '
        Me.QRibbon1.Location = New System.Drawing.Point(50, 65)
        Me.QRibbon1.Name = "QRibbon1"
        Me.QRibbon1.PersistGuid = New System.Guid("4ca42e8e-880f-47e8-ab96-05313ef08b91")
        Me.QRibbon1.Size = New System.Drawing.Size(75, 50)
        Me.QRibbon1.TabIndex = 0
        Me.QRibbon1.Text = "QRibbon1"
        '
        'newribbon
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.QRibbon1)
        Me.Name = "newribbon"
        Me.Text = "Form4"
        CType(Me.QRibbon1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents QRibbon1 As Qios.DevSuite.Components.Ribbon.QRibbon
End Class
