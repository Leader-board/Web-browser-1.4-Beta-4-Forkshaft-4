using System;
using System.Collections.Generic;
using System.Text;

namespace System.Windows.Forms
{
    public interface IRibbonForm
    {
        RibbonFormHelper Helper { get; }
    }
}
