﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Leaderboard Web browser 1.4 Beta 4 Forkshaft 4")> 
<Assembly: AssemblyDescription("Web browser. Based on a hybrid of Ribbon GUI and the familiar Menu interface , it attempts to strike a balance between Ribbon and Menu. It allows you to choose between the familiar-to-many Menu and the simplified Ribbon interface , among many appearance options. Please note as you may expect bugs at this stage.")> 
<Assembly: AssemblyCompany("Leaderboard")> 
<Assembly: AssemblyProduct("Leaderboard Web browser 1.4 Pre-Beta 4")> 
<Assembly: AssemblyCopyright("Copyright © Leaderboard 2013")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("aeb411ab-2aa1-4c3c-8686-e7ddb89d88c2")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.40.7.4")> 
<Assembly: AssemblyFileVersion("1.40.7.4")> 
