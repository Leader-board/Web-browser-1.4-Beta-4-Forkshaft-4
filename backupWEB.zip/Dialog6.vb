﻿Imports System.Windows.Forms

Public Class Dialog6

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click

        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click

        Me.Close()
    End Sub

   

    Private Sub Dialog6_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
