﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.PrintDialog1 = New System.Windows.Forms.PrintDialog()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.GroupBox13 = New System.Windows.Forms.GroupBox()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.ribbon_search = New System.Windows.Forms.TextBox()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.TabPage10 = New System.Windows.Forms.TabPage()
        Me.GroupBox23 = New System.Windows.Forms.GroupBox()
        Me.Button40 = New System.Windows.Forms.Button()
        Me.Button39 = New System.Windows.Forms.Button()
        Me.GroupBox22 = New System.Windows.Forms.GroupBox()
        Me.Button38 = New System.Windows.Forms.Button()
        Me.Button37 = New System.Windows.Forms.Button()
        Me.GroupBox21 = New System.Windows.Forms.GroupBox()
        Me.Button36 = New System.Windows.Forms.Button()
        Me.Button35 = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.RadioButton4 = New System.Windows.Forms.RadioButton()
        Me.RadioButton3 = New System.Windows.Forms.RadioButton()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.btnribfavourites = New System.Windows.Forms.Button()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Button33 = New System.Windows.Forms.Button()
        Me.GroupBox20 = New System.Windows.Forms.GroupBox()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.TabPage11 = New System.Windows.Forms.TabPage()
        Me.GroupBox17 = New System.Windows.Forms.GroupBox()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.ribhistorysearch = New System.Windows.Forms.ComboBox()
        Me.GroupBox16 = New System.Windows.Forms.GroupBox()
        Me.ribfavourite = New System.Windows.Forms.ComboBox()
        Me.GroupBox15 = New System.Windows.Forms.GroupBox()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.ribhistory = New System.Windows.Forms.ComboBox()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.GroupBox18 = New System.Windows.Forms.GroupBox()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.GroupBox19 = New System.Windows.Forms.GroupBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MainToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HomeToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrereleaseAppStoreToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WebInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WebpageTypeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Tab1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.menudocumentype1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Tab2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.menudocumentype2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.EncryptionLevelToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuencryptlevel1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuencry = New System.Windows.Forms.ToolStripMenuItem()
        Me.Tab2ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuencryptlevel2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.WebpageDomainToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Tab1ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuwebdomain1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Tab2ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuwebdomain2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PageTitleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Tab1ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.menupagetitle1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Tab2ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.menupagetitle2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.WebpathToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Tab1ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuwebpath1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Tab2ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuwebpath2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewHTMLCodeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SystemInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OSNameToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuOSName = New System.Windows.Forms.ToolStripMenuItem()
        Me.ArchitectureToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.menubitcount = New System.Windows.Forms.ToolStripMenuItem()
        Me.ComputerNameToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.menucomputername = New System.Windows.Forms.ToolStripMenuItem()
        Me.MemoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AvailableRAMInstalledToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuRAM = New System.Windows.Forms.ToolStripMenuItem()
        Me.FreeRAMAvailableToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.menufreeRAM = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutTheBrowserToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LeaderboardWebBrowser14Beta4Forkshaft4ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Build96ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Version1474ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EngineTridentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContributorsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PageOptionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GoBackToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GoForwardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RefreshToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HomeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GoToPageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripTextBox1 = New System.Windows.Forms.ToolStripTextBox()
        Me.BackgroundToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MankYourOwnMessageBoxToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClearTheWebpageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintAPageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DisableScriptingErrorsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BlenderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RibbonToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TipsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuColourOptionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetHomePageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AdvancedWebSettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangeSearchBaseEngineToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HistoryFavouritesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HistoryToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuhistory = New System.Windows.Forms.ToolStripComboBox()
        Me.SearchBaseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuhistorysearch = New System.Windows.Forms.ToolStripComboBox()
        Me.FavouritesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.menufavourties = New System.Windows.Forms.ToolStripComboBox()
        Me.ActivateSearchBarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddFavouritesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DisplayStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResizingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DisableToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EnableToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MainTitleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DisableToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.EnableToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DefaultMaximizeMinimizeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DisableToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.EnableToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuHelpAbout = New System.Windows.Forms.ToolStripMenuItem()
        Me.RerunFirstRunWizardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.PerformanceCounter1 = New System.Diagnostics.PerformanceCounter()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.TabControl3 = New System.Windows.Forms.TabControl()
        Me.TabPage13 = New System.Windows.Forms.TabPage()
        Me.Webbrowser2 = New Skybound.Gecko.GeckoWebBrowser()
        Me.WebBrowser2a = New System.Windows.Forms.WebBrowser()
        Me.TabPage12 = New System.Windows.Forms.TabPage()
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.pinapp_2 = New System.Windows.Forms.Button()
        Me.pinapp_1 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.LineShape1 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ShapeContainer2 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.LineShape3 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.LineShape2 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.GroupBox14 = New System.Windows.Forms.GroupBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox13.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage10.SuspendLayout()
        Me.GroupBox23.SuspendLayout()
        Me.GroupBox22.SuspendLayout()
        Me.GroupBox21.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox20.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.TabPage11.SuspendLayout()
        Me.GroupBox17.SuspendLayout()
        Me.GroupBox16.SuspendLayout()
        Me.GroupBox15.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.GroupBox18.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.GroupBox19.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        CType(Me.PerformanceCounter1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.TabControl3.SuspendLayout()
        Me.TabPage13.SuspendLayout()
        Me.TabPage12.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.GroupBox12.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        Me.GroupBox14.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage9.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        Me.OpenFileDialog1.Filter = "HTML files (*.htm / *.html) | (*.html) "
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.Filter = resources.GetString("SaveFileDialog1.Filter")
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.Text = "NotifyIcon1"
        Me.NotifyIcon1.Visible = True
        '
        'PrintDialog1
        '
        Me.PrintDialog1.AllowCurrentPage = True
        Me.PrintDialog1.AllowSelection = True
        Me.PrintDialog1.AllowSomePages = True
        Me.PrintDialog1.PrintToFile = True
        Me.PrintDialog1.UseEXDialog = True
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'ToolTip1
        '
        Me.ToolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info
        Me.ToolTip1.ToolTipTitle = "A goood hint"
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(3, 38)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(119, 26)
        Me.Button11.TabIndex = 5
        Me.Button11.Text = "Home"
        Me.ToolTip1.SetToolTip(Me.Button11, "Loads your Home page.")
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(118, 39)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(102, 26)
        Me.Button9.TabIndex = 3
        Me.Button9.Text = "Refresh"
        Me.ToolTip1.SetToolTip(Me.Button9, "Refreshes the page.")
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(139, 14)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(102, 26)
        Me.Button8.TabIndex = 2
        Me.Button8.Text = "Stop"
        Me.ToolTip1.SetToolTip(Me.Button8, "Stops the page from being viewed.")
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(73, 14)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(73, 26)
        Me.Button7.TabIndex = 1
        Me.Button7.Text = "Go forward"
        Me.ToolTip1.SetToolTip(Me.Button7, "Goes to the next webpage.")
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(0, 19)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(156, 27)
        Me.Button17.TabIndex = 4
        Me.Button17.Text = "Ribbon/Menu selection mode"
        Me.ToolTip1.SetToolTip(Me.Button17, "Allows you to choose whether you need the Ribbon interface or the Menu interface")
        Me.Button17.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(1, 19)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(75, 25)
        Me.Button14.TabIndex = 0
        Me.Button14.Text = "About"
        Me.ToolTip1.SetToolTip(Me.Button14, "Displays info about this application")
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(13, 19)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(75, 25)
        Me.Button15.TabIndex = 0
        Me.Button15.Text = "Close"
        Me.ToolTip1.SetToolTip(Me.Button15, "Closes the browser.")
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(4, 20)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(132, 36)
        Me.Button13.TabIndex = 3
        Me.Button13.Text = "Make your own message box"
        Me.ToolTip1.SetToolTip(Me.Button13, "Helps you to make your own message box")
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.Location = New System.Drawing.Point(1, 21)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(129, 32)
        Me.Button18.TabIndex = 10
        Me.Button18.Text = "Clear the webpage"
        Me.ToolTip1.SetToolTip(Me.Button18, "Clears everything on the webpage")
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(597, 27)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 25)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Go!"
        Me.ToolTip1.SetToolTip(Me.Button1, "Goes to the page specified on the Address bar on the left.")
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(120, 29)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 25)
        Me.Button3.TabIndex = 5
        Me.Button3.Text = "Refresh"
        Me.ToolTip1.SetToolTip(Me.Button3, "Refreshes the page")
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(201, 29)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(75, 25)
        Me.Button5.TabIndex = 7
        Me.Button5.Text = "Stop"
        Me.ToolTip1.SetToolTip(Me.Button5, "Stops the page from being viewed.")
        Me.Button5.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(282, 31)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(309, 20)
        Me.TextBox1.TabIndex = 8
        Me.ToolTip1.SetToolTip(Me.TextBox1, "The Address bar. Used with the Go! on the right")
        '
        'Button19
        '
        Me.Button19.Location = New System.Drawing.Point(129, 22)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(129, 31)
        Me.Button19.TabIndex = 11
        Me.Button19.Text = "Print webpage"
        Me.ToolTip1.SetToolTip(Me.Button19, "Prints the current page.")
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(55, 29)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(59, 25)
        Me.Button4.TabIndex = 6
        Me.Button4.Text = "Forward"
        Me.ToolTip1.SetToolTip(Me.Button4, "Goes to the next page")
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(0, 29)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(49, 25)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "Back"
        Me.ToolTip1.SetToolTip(Me.Button2, "Goes to the previous page")
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.Location = New System.Drawing.Point(343, 40)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(70, 24)
        Me.Button22.TabIndex = 1
        Me.Button22.Text = "Go!"
        Me.ToolTip1.SetToolTip(Me.Button22, "Accesses the webpage you specified on the address bar on the top.")
        Me.Button22.UseVisualStyleBackColor = True
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(6, 17)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox2.Size = New System.Drawing.Size(411, 20)
        Me.TextBox2.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.TextBox2, "The Address bar. It is used with the Go! on the downside.")
        '
        'Button23
        '
        Me.Button23.Location = New System.Drawing.Point(3, 19)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(162, 29)
        Me.Button23.TabIndex = 0
        Me.Button23.Text = "Ribbon Tab mode"
        Me.ToolTip1.SetToolTip(Me.Button23, "Allows you to set the type of the Ribbon tabs.")
        Me.Button23.UseVisualStyleBackColor = True
        '
        'Button27
        '
        Me.Button27.Location = New System.Drawing.Point(162, 20)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(156, 28)
        Me.Button27.TabIndex = 1
        Me.Button27.Text = "Tab colour changer"
        Me.ToolTip1.SetToolTip(Me.Button27, "Changes the colour of the Tabs.")
        Me.Button27.UseVisualStyleBackColor = True
        '
        'GroupBox13
        '
        Me.GroupBox13.Controls.Add(Me.LinkLabel2)
        Me.GroupBox13.Controls.Add(Me.Button10)
        Me.GroupBox13.Controls.Add(Me.ribbon_search)
        Me.GroupBox13.Controls.Add(Me.Button28)
        Me.GroupBox13.Location = New System.Drawing.Point(454, 95)
        Me.GroupBox13.Name = "GroupBox13"
        Me.GroupBox13.Size = New System.Drawing.Size(317, 52)
        Me.GroupBox13.TabIndex = 5
        Me.GroupBox13.TabStop = False
        Me.GroupBox13.Text = "Search"
        Me.ToolTip1.SetToolTip(Me.GroupBox13, "Use this place to search")
        Me.GroupBox13.Visible = False
        '
        'LinkLabel2
        '
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.Location = New System.Drawing.Point(55, 1)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(46, 14)
        Me.LinkLabel2.TabIndex = 3
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "Settings"
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(229, 29)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(75, 23)
        Me.Button10.TabIndex = 2
        Me.Button10.Text = "< Hide"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'ribbon_search
        '
        Me.ribbon_search.Location = New System.Drawing.Point(6, 19)
        Me.ribbon_search.Multiline = True
        Me.ribbon_search.Name = "ribbon_search"
        Me.ribbon_search.Size = New System.Drawing.Size(165, 27)
        Me.ribbon_search.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.ribbon_search, "Search what you want here")
        '
        'Button28
        '
        Me.Button28.Location = New System.Drawing.Point(229, 8)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(75, 23)
        Me.Button28.TabIndex = 1
        Me.Button28.Text = "Search"
        Me.Button28.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(6, 23)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(46, 18)
        Me.CheckBox1.TabIndex = 0
        Me.CheckBox1.Text = "Tips"
        Me.ToolTip1.SetToolTip(Me.CheckBox1, "Selects the optionsl for Tips.")
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'Button30
        '
        Me.Button30.Location = New System.Drawing.Point(9, 31)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(138, 23)
        Me.Button30.TabIndex = 0
        Me.Button30.Text = "Rerun wizard"
        Me.ToolTip1.SetToolTip(Me.Button30, "Closes the browser and starts up the First Run Wizard")
        Me.Button30.UseVisualStyleBackColor = True
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(1, 96)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(68, 14)
        Me.Label21.TabIndex = 2
        Me.Label21.Text = "OS Version"
        Me.ToolTip1.SetToolTip(Me.Label21, "Displays the version of the OS installed on your PC.")
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(136, 123)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(56, 14)
        Me.Label24.TabIndex = 5
        Me.Label24.Text = "(bit count)"
        Me.ToolTip1.SetToolTip(Me.Label24, "Displays the architecture of your computer")
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(1, 151)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(97, 14)
        Me.Label25.TabIndex = 6
        Me.Label25.Text = "Computer name"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.ToolTip1.SetToolTip(Me.Label25, "Displays the name of the computer")
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(136, 208)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(44, 14)
        Me.Label30.TabIndex = 11
        Me.Label30.Text = "(RAMF)"
        Me.ToolTip1.SetToolTip(Me.Label30, "Displays the amount of free RAM on the computer")
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(0, 20)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(67, 14)
        Me.Label36.TabIndex = 0
        Me.Label36.Text = "Connected"
        Me.ToolTip1.SetToolTip(Me.Label36, "Displayes if the network is connected")
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(285, 17)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(228, 36)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "unknown"
        Me.ToolTip1.SetToolTip(Me.Label4, "This is the title. If it's blank , it probably means that you haven't visited a w" & _
        "ebsite.")
        '
        'Button20
        '
        Me.Button20.Location = New System.Drawing.Point(689, 330)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(91, 22)
        Me.Button20.TabIndex = 2
        Me.Button20.Text = "Close"
        Me.ToolTip1.SetToolTip(Me.Button20, "Closes the Ribbon Backstage view and returns to the main web browser.")
        Me.Button20.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.WindowsApplication.My.Resources.Resources._1379523912_or_56092
        Me.PictureBox1.Location = New System.Drawing.Point(-2, -1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(84, 90)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 12
        Me.PictureBox1.TabStop = False
        Me.ToolTip1.SetToolTip(Me.PictureBox1, "Click this picture to open the Ribbon backstage view and find out what you can do" & _
        "....")
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(3, 14)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(75, 26)
        Me.Button6.TabIndex = 0
        Me.Button6.Text = "Go back"
        Me.ToolTip1.SetToolTip(Me.Button6, "Goes to the previous webpage")
        Me.Button6.UseVisualStyleBackColor = True
        '
        'TabPage10
        '
        Me.TabPage10.Controls.Add(Me.GroupBox23)
        Me.TabPage10.Controls.Add(Me.GroupBox22)
        Me.TabPage10.Controls.Add(Me.GroupBox21)
        Me.TabPage10.Location = New System.Drawing.Point(4, 23)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Size = New System.Drawing.Size(1978, 66)
        Me.TabPage10.TabIndex = 5
        Me.TabPage10.Text = "Window"
        Me.ToolTip1.SetToolTip(Me.TabPage10, "This tab controls the display area , including resolution-disabling")
        Me.TabPage10.UseVisualStyleBackColor = True
        '
        'GroupBox23
        '
        Me.GroupBox23.Controls.Add(Me.Button40)
        Me.GroupBox23.Controls.Add(Me.Button39)
        Me.GroupBox23.Location = New System.Drawing.Point(240, 3)
        Me.GroupBox23.Name = "GroupBox23"
        Me.GroupBox23.Size = New System.Drawing.Size(148, 60)
        Me.GroupBox23.TabIndex = 2
        Me.GroupBox23.TabStop = False
        Me.GroupBox23.Text = "Maximise/Minimise"
        '
        'Button40
        '
        Me.Button40.Location = New System.Drawing.Point(-4, 39)
        Me.Button40.Name = "Button40"
        Me.Button40.Size = New System.Drawing.Size(152, 23)
        Me.Button40.TabIndex = 1
        Me.Button40.Text = "Disable"
        Me.Button40.UseVisualStyleBackColor = True
        '
        'Button39
        '
        Me.Button39.Location = New System.Drawing.Point(0, 24)
        Me.Button39.Name = "Button39"
        Me.Button39.Size = New System.Drawing.Size(154, 20)
        Me.Button39.TabIndex = 0
        Me.Button39.Text = "Enable"
        Me.Button39.UseVisualStyleBackColor = True
        '
        'GroupBox22
        '
        Me.GroupBox22.Controls.Add(Me.Button38)
        Me.GroupBox22.Controls.Add(Me.Button37)
        Me.GroupBox22.Location = New System.Drawing.Point(109, 0)
        Me.GroupBox22.Name = "GroupBox22"
        Me.GroupBox22.Size = New System.Drawing.Size(125, 67)
        Me.GroupBox22.TabIndex = 1
        Me.GroupBox22.TabStop = False
        Me.GroupBox22.Text = "Main title"
        '
        'Button38
        '
        Me.Button38.Location = New System.Drawing.Point(0, 39)
        Me.Button38.Name = "Button38"
        Me.Button38.Size = New System.Drawing.Size(114, 23)
        Me.Button38.TabIndex = 1
        Me.Button38.Text = "Disable"
        Me.Button38.UseVisualStyleBackColor = True
        '
        'Button37
        '
        Me.Button37.Location = New System.Drawing.Point(0, 18)
        Me.Button37.Name = "Button37"
        Me.Button37.Size = New System.Drawing.Size(114, 23)
        Me.Button37.TabIndex = 0
        Me.Button37.Text = "Enable"
        Me.Button37.UseVisualStyleBackColor = True
        '
        'GroupBox21
        '
        Me.GroupBox21.Controls.Add(Me.Button36)
        Me.GroupBox21.Controls.Add(Me.Button35)
        Me.GroupBox21.Location = New System.Drawing.Point(2, 0)
        Me.GroupBox21.Name = "GroupBox21"
        Me.GroupBox21.Size = New System.Drawing.Size(109, 65)
        Me.GroupBox21.TabIndex = 0
        Me.GroupBox21.TabStop = False
        Me.GroupBox21.Text = "Resizing"
        '
        'Button36
        '
        Me.Button36.Location = New System.Drawing.Point(1, 40)
        Me.Button36.Name = "Button36"
        Me.Button36.Size = New System.Drawing.Size(109, 23)
        Me.Button36.TabIndex = 1
        Me.Button36.Text = "Disable"
        Me.Button36.UseVisualStyleBackColor = True
        '
        'Button35
        '
        Me.Button35.Location = New System.Drawing.Point(1, 19)
        Me.Button35.Name = "Button35"
        Me.Button35.Size = New System.Drawing.Size(108, 23)
        Me.Button35.TabIndex = 0
        Me.Button35.Text = "Enable"
        Me.Button35.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.RadioButton4)
        Me.Panel1.Controls.Add(Me.RadioButton3)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Controls.Add(Me.TextBox1)
        Me.Panel1.Controls.Add(Me.Button5)
        Me.Panel1.Controls.Add(Me.TabControl1)
        Me.Panel1.Controls.Add(Me.Button4)
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Controls.Add(Me.Button2)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.MenuStrip1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(783, 93)
        Me.Panel1.TabIndex = 0
        '
        'RadioButton4
        '
        Me.RadioButton4.AutoSize = True
        Me.RadioButton4.Location = New System.Drawing.Point(346, 52)
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.Size = New System.Drawing.Size(48, 18)
        Me.RadioButton4.TabIndex = 1
        Me.RadioButton4.TabStop = True
        Me.RadioButton4.Text = "Tab2"
        Me.RadioButton4.UseVisualStyleBackColor = True
        '
        'RadioButton3
        '
        Me.RadioButton3.AutoSize = True
        Me.RadioButton3.Checked = True
        Me.RadioButton3.Location = New System.Drawing.Point(292, 52)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(48, 18)
        Me.RadioButton3.TabIndex = 0
        Me.RadioButton3.TabStop = True
        Me.RadioButton3.Text = "Tab1"
        Me.RadioButton3.UseVisualStyleBackColor = True
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage11)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage10)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.HotTrack = True
        Me.TabControl1.Location = New System.Drawing.Point(79, 0)
        Me.TabControl1.Multiline = True
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.ShowToolTips = True
        Me.TabControl1.Size = New System.Drawing.Size(1986, 93)
        Me.TabControl1.TabIndex = 3
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.Transparent
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 23)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1978, 66)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Webpage"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.RadioButton2)
        Me.GroupBox2.Controls.Add(Me.RadioButton1)
        Me.GroupBox2.Controls.Add(Me.btnribfavourites)
        Me.GroupBox2.Controls.Add(Me.Button29)
        Me.GroupBox2.Controls.Add(Me.Button22)
        Me.GroupBox2.Controls.Add(Me.TextBox2)
        Me.GroupBox2.Location = New System.Drawing.Point(275, 0)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(429, 70)
        Me.GroupBox2.TabIndex = 7
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Webpage entry"
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(52, 40)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(48, 18)
        Me.RadioButton2.TabIndex = 5
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "Tab2"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Checked = True
        Me.RadioButton1.Location = New System.Drawing.Point(7, 40)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(48, 18)
        Me.RadioButton1.TabIndex = 4
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Tab1"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'btnribfavourites
        '
        Me.btnribfavourites.Location = New System.Drawing.Point(185, 40)
        Me.btnribfavourites.Name = "btnribfavourites"
        Me.btnribfavourites.Size = New System.Drawing.Size(81, 23)
        Me.btnribfavourites.TabIndex = 3
        Me.btnribfavourites.Text = "Favourites >>"
        Me.btnribfavourites.UseVisualStyleBackColor = True
        '
        'Button29
        '
        Me.Button29.Location = New System.Drawing.Point(262, 40)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(75, 23)
        Me.Button29.TabIndex = 2
        Me.Button29.Text = "Search >"
        Me.Button29.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Button9)
        Me.GroupBox1.Controls.Add(Me.Button11)
        Me.GroupBox1.Controls.Add(Me.Button8)
        Me.GroupBox1.Controls.Add(Me.Button7)
        Me.GroupBox1.Controls.Add(Me.Button6)
        Me.GroupBox1.Location = New System.Drawing.Point(3, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(277, 67)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Navigating tools"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Button33)
        Me.TabPage2.Controls.Add(Me.GroupBox20)
        Me.TabPage2.Controls.Add(Me.GroupBox9)
        Me.TabPage2.Controls.Add(Me.GroupBox7)
        Me.TabPage2.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.TabPage2.Location = New System.Drawing.Point(4, 23)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1978, 66)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Options"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Button33
        '
        Me.Button33.Location = New System.Drawing.Point(477, 19)
        Me.Button33.Name = "Button33"
        Me.Button33.Size = New System.Drawing.Size(100, 40)
        Me.Button33.TabIndex = 9
        Me.Button33.Text = ">Advaned settings"
        Me.Button33.UseVisualStyleBackColor = True
        '
        'GroupBox20
        '
        Me.GroupBox20.Controls.Add(Me.Button31)
        Me.GroupBox20.Location = New System.Drawing.Point(577, 0)
        Me.GroupBox20.Name = "GroupBox20"
        Me.GroupBox20.Size = New System.Drawing.Size(115, 67)
        Me.GroupBox20.TabIndex = 8
        Me.GroupBox20.TabStop = False
        Me.GroupBox20.Text = "HomePage"
        '
        'Button31
        '
        Me.Button31.Location = New System.Drawing.Point(6, 23)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(103, 23)
        Me.Button31.TabIndex = 0
        Me.Button31.Text = "Set home page"
        Me.Button31.UseVisualStyleBackColor = True
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.Button27)
        Me.GroupBox9.Controls.Add(Me.Button23)
        Me.GroupBox9.Location = New System.Drawing.Point(162, 0)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(318, 65)
        Me.GroupBox9.TabIndex = 6
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Appearance settings"
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.Button17)
        Me.GroupBox7.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(162, 65)
        Me.GroupBox7.TabIndex = 5
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Options"
        '
        'TabPage11
        '
        Me.TabPage11.Controls.Add(Me.GroupBox17)
        Me.TabPage11.Controls.Add(Me.GroupBox16)
        Me.TabPage11.Controls.Add(Me.GroupBox15)
        Me.TabPage11.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.TabPage11.Location = New System.Drawing.Point(4, 23)
        Me.TabPage11.Name = "TabPage11"
        Me.TabPage11.Size = New System.Drawing.Size(1978, 66)
        Me.TabPage11.TabIndex = 6
        Me.TabPage11.Text = "History/Favourites"
        Me.TabPage11.UseVisualStyleBackColor = True
        '
        'GroupBox17
        '
        Me.GroupBox17.Controls.Add(Me.Button32)
        Me.GroupBox17.Controls.Add(Me.ribhistorysearch)
        Me.GroupBox17.Location = New System.Drawing.Point(227, 0)
        Me.GroupBox17.Name = "GroupBox17"
        Me.GroupBox17.Size = New System.Drawing.Size(258, 70)
        Me.GroupBox17.TabIndex = 2
        Me.GroupBox17.TabStop = False
        Me.GroupBox17.Text = "StoreSearch"
        '
        'Button32
        '
        Me.Button32.Location = New System.Drawing.Point(6, 41)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(75, 23)
        Me.Button32.TabIndex = 1
        Me.Button32.Text = "Search>>"
        Me.Button32.UseVisualStyleBackColor = True
        '
        'ribhistorysearch
        '
        Me.ribhistorysearch.FormattingEnabled = True
        Me.ribhistorysearch.Location = New System.Drawing.Point(6, 19)
        Me.ribhistorysearch.Name = "ribhistorysearch"
        Me.ribhistorysearch.Size = New System.Drawing.Size(230, 22)
        Me.ribhistorysearch.TabIndex = 0
        '
        'GroupBox16
        '
        Me.GroupBox16.Controls.Add(Me.ribfavourite)
        Me.GroupBox16.Location = New System.Drawing.Point(482, 0)
        Me.GroupBox16.Name = "GroupBox16"
        Me.GroupBox16.Size = New System.Drawing.Size(210, 67)
        Me.GroupBox16.TabIndex = 1
        Me.GroupBox16.TabStop = False
        Me.GroupBox16.Text = "Favourites"
        '
        'ribfavourite
        '
        Me.ribfavourite.FormattingEnabled = True
        Me.ribfavourite.Location = New System.Drawing.Point(7, 20)
        Me.ribfavourite.Name = "ribfavourite"
        Me.ribfavourite.Size = New System.Drawing.Size(185, 22)
        Me.ribfavourite.TabIndex = 0
        '
        'GroupBox15
        '
        Me.GroupBox15.Controls.Add(Me.Button26)
        Me.GroupBox15.Controls.Add(Me.ribhistory)
        Me.GroupBox15.Location = New System.Drawing.Point(4, 0)
        Me.GroupBox15.Name = "GroupBox15"
        Me.GroupBox15.Size = New System.Drawing.Size(222, 69)
        Me.GroupBox15.TabIndex = 0
        Me.GroupBox15.TabStop = False
        Me.GroupBox15.Text = "History"
        '
        'Button26
        '
        Me.Button26.Location = New System.Drawing.Point(6, 41)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(75, 23)
        Me.Button26.TabIndex = 1
        Me.Button26.Text = "Navigate>>"
        Me.Button26.UseVisualStyleBackColor = True
        '
        'ribhistory
        '
        Me.ribhistory.FormattingEnabled = True
        Me.ribhistory.Location = New System.Drawing.Point(6, 19)
        Me.ribhistory.Name = "ribhistory"
        Me.ribhistory.Size = New System.Drawing.Size(217, 22)
        Me.ribhistory.TabIndex = 0
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.GroupBox18)
        Me.TabPage5.Controls.Add(Me.GroupBox5)
        Me.TabPage5.Controls.Add(Me.GroupBox3)
        Me.TabPage5.Location = New System.Drawing.Point(4, 23)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(1978, 66)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Tools"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'GroupBox18
        '
        Me.GroupBox18.Controls.Add(Me.Button12)
        Me.GroupBox18.Location = New System.Drawing.Point(426, 1)
        Me.GroupBox18.Name = "GroupBox18"
        Me.GroupBox18.Size = New System.Drawing.Size(94, 63)
        Me.GroupBox18.TabIndex = 8
        Me.GroupBox18.TabStop = False
        Me.GroupBox18.Text = "Blender"
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(6, 19)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(88, 29)
        Me.Button12.TabIndex = 0
        Me.Button12.Text = "Set blender"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Button19)
        Me.GroupBox5.Controls.Add(Me.Button18)
        Me.GroupBox5.Location = New System.Drawing.Point(162, 5)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(262, 59)
        Me.GroupBox5.TabIndex = 6
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Web tools"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Button13)
        Me.GroupBox3.Location = New System.Drawing.Point(3, 4)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(149, 63)
        Me.GroupBox3.TabIndex = 5
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Non-web tools"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.GroupBox19)
        Me.TabPage3.Controls.Add(Me.GroupBox6)
        Me.TabPage3.Controls.Add(Me.GroupBox4)
        Me.TabPage3.Location = New System.Drawing.Point(4, 23)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1978, 66)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Help"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'GroupBox19
        '
        Me.GroupBox19.Controls.Add(Me.Button30)
        Me.GroupBox19.Location = New System.Drawing.Point(294, 4)
        Me.GroupBox19.Name = "GroupBox19"
        Me.GroupBox19.Size = New System.Drawing.Size(200, 66)
        Me.GroupBox19.TabIndex = 7
        Me.GroupBox19.TabStop = False
        Me.GroupBox19.Text = "First Run Wizard"
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.Button16)
        Me.GroupBox6.Controls.Add(Me.CheckBox1)
        Me.GroupBox6.Location = New System.Drawing.Point(124, 3)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(172, 67)
        Me.GroupBox6.TabIndex = 6
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Tip Options"
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(71, 19)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(71, 25)
        Me.Button16.TabIndex = 1
        Me.Button16.Text = "Apply"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Button14)
        Me.GroupBox4.Location = New System.Drawing.Point(2, 3)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(120, 62)
        Me.GroupBox4.TabIndex = 5
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Help"
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.White
        Me.TabPage4.Controls.Add(Me.GroupBox8)
        Me.TabPage4.Location = New System.Drawing.Point(4, 23)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(1978, 66)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Exit"
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.Button15)
        Me.GroupBox8.Location = New System.Drawing.Point(2, 2)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(113, 63)
        Me.GroupBox8.TabIndex = 1
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Exit"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.IndianRed
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MainToolStripMenuItem, Me.PageOptionsToolStripMenuItem, Me.BackgroundToolStripMenuItem, Me.ToolsToolStripMenuItem, Me.HistoryFavouritesToolStripMenuItem, Me.DisplayStripMenuItem, Me.HelpToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.MenuStrip1.Size = New System.Drawing.Size(783, 24)
        Me.MenuStrip1.TabIndex = 3
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MainToolStripMenuItem
        '
        Me.MainToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HomeToolStripMenuItem1, Me.WebInfoToolStripMenuItem, Me.SystemInfoToolStripMenuItem, Me.AboutToolStripMenuItem})
        Me.MainToolStripMenuItem.Name = "MainToolStripMenuItem"
        Me.MainToolStripMenuItem.Size = New System.Drawing.Size(46, 20)
        Me.MainToolStripMenuItem.Text = "Main"
        '
        'HomeToolStripMenuItem1
        '
        Me.HomeToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PrereleaseAppStoreToolStripMenuItem})
        Me.HomeToolStripMenuItem1.Name = "HomeToolStripMenuItem1"
        Me.HomeToolStripMenuItem1.Size = New System.Drawing.Size(136, 22)
        Me.HomeToolStripMenuItem1.Text = "Home"
        '
        'PrereleaseAppStoreToolStripMenuItem
        '
        Me.PrereleaseAppStoreToolStripMenuItem.Name = "PrereleaseAppStoreToolStripMenuItem"
        Me.PrereleaseAppStoreToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.PrereleaseAppStoreToolStripMenuItem.Text = "Pre-release App Store"
        '
        'WebInfoToolStripMenuItem
        '
        Me.WebInfoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.WebpageTypeToolStripMenuItem, Me.EncryptionLevelToolStripMenuItem, Me.WebpageDomainToolStripMenuItem, Me.PageTitleToolStripMenuItem, Me.WebpathToolStripMenuItem, Me.ViewHTMLCodeToolStripMenuItem})
        Me.WebInfoToolStripMenuItem.Name = "WebInfoToolStripMenuItem"
        Me.WebInfoToolStripMenuItem.Size = New System.Drawing.Size(136, 22)
        Me.WebInfoToolStripMenuItem.Text = "Web info"
        '
        'WebpageTypeToolStripMenuItem
        '
        Me.WebpageTypeToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Tab1ToolStripMenuItem, Me.Tab2ToolStripMenuItem})
        Me.WebpageTypeToolStripMenuItem.Name = "WebpageTypeToolStripMenuItem"
        Me.WebpageTypeToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.WebpageTypeToolStripMenuItem.Text = "Webpage type"
        '
        'Tab1ToolStripMenuItem
        '
        Me.Tab1ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menudocumentype1})
        Me.Tab1ToolStripMenuItem.Name = "Tab1ToolStripMenuItem"
        Me.Tab1ToolStripMenuItem.Size = New System.Drawing.Size(100, 22)
        Me.Tab1ToolStripMenuItem.Text = "Tab1"
        '
        'menudocumentype1
        '
        Me.menudocumentype1.Name = "menudocumentype1"
        Me.menudocumentype1.Size = New System.Drawing.Size(80, 22)
        Me.menudocumentype1.Text = "0"
        '
        'Tab2ToolStripMenuItem
        '
        Me.Tab2ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menudocumentype2})
        Me.Tab2ToolStripMenuItem.Name = "Tab2ToolStripMenuItem"
        Me.Tab2ToolStripMenuItem.Size = New System.Drawing.Size(100, 22)
        Me.Tab2ToolStripMenuItem.Text = "Tab2"
        '
        'menudocumentype2
        '
        Me.menudocumentype2.Name = "menudocumentype2"
        Me.menudocumentype2.Size = New System.Drawing.Size(80, 22)
        Me.menudocumentype2.Text = "0"
        '
        'EncryptionLevelToolStripMenuItem
        '
        Me.EncryptionLevelToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuencryptlevel1, Me.Tab2ToolStripMenuItem1})
        Me.EncryptionLevelToolStripMenuItem.Name = "EncryptionLevelToolStripMenuItem"
        Me.EncryptionLevelToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.EncryptionLevelToolStripMenuItem.Text = "Encryption level"
        '
        'menuencryptlevel1
        '
        Me.menuencryptlevel1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuencry})
        Me.menuencryptlevel1.Name = "menuencryptlevel1"
        Me.menuencryptlevel1.Size = New System.Drawing.Size(100, 22)
        Me.menuencryptlevel1.Text = "Tab1"
        '
        'menuencry
        '
        Me.menuencry.Name = "menuencry"
        Me.menuencry.Size = New System.Drawing.Size(80, 22)
        Me.menuencry.Text = "0"
        '
        'Tab2ToolStripMenuItem1
        '
        Me.Tab2ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuencryptlevel2})
        Me.Tab2ToolStripMenuItem1.Name = "Tab2ToolStripMenuItem1"
        Me.Tab2ToolStripMenuItem1.Size = New System.Drawing.Size(100, 22)
        Me.Tab2ToolStripMenuItem1.Text = "Tab2"
        '
        'menuencryptlevel2
        '
        Me.menuencryptlevel2.Name = "menuencryptlevel2"
        Me.menuencryptlevel2.Size = New System.Drawing.Size(80, 22)
        Me.menuencryptlevel2.Text = "0"
        '
        'WebpageDomainToolStripMenuItem
        '
        Me.WebpageDomainToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Tab1ToolStripMenuItem1, Me.Tab2ToolStripMenuItem2})
        Me.WebpageDomainToolStripMenuItem.Name = "WebpageDomainToolStripMenuItem"
        Me.WebpageDomainToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.WebpageDomainToolStripMenuItem.Text = "Webpage domain"
        '
        'Tab1ToolStripMenuItem1
        '
        Me.Tab1ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuwebdomain1})
        Me.Tab1ToolStripMenuItem1.Name = "Tab1ToolStripMenuItem1"
        Me.Tab1ToolStripMenuItem1.Size = New System.Drawing.Size(100, 22)
        Me.Tab1ToolStripMenuItem1.Text = "Tab1"
        '
        'menuwebdomain1
        '
        Me.menuwebdomain1.Name = "menuwebdomain1"
        Me.menuwebdomain1.Size = New System.Drawing.Size(80, 22)
        Me.menuwebdomain1.Text = "0"
        '
        'Tab2ToolStripMenuItem2
        '
        Me.Tab2ToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuwebdomain2})
        Me.Tab2ToolStripMenuItem2.Name = "Tab2ToolStripMenuItem2"
        Me.Tab2ToolStripMenuItem2.Size = New System.Drawing.Size(100, 22)
        Me.Tab2ToolStripMenuItem2.Text = "Tab2"
        '
        'menuwebdomain2
        '
        Me.menuwebdomain2.Name = "menuwebdomain2"
        Me.menuwebdomain2.Size = New System.Drawing.Size(80, 22)
        Me.menuwebdomain2.Text = "0"
        '
        'PageTitleToolStripMenuItem
        '
        Me.PageTitleToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Tab1ToolStripMenuItem2, Me.Tab2ToolStripMenuItem3})
        Me.PageTitleToolStripMenuItem.Name = "PageTitleToolStripMenuItem"
        Me.PageTitleToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.PageTitleToolStripMenuItem.Text = "Page title"
        '
        'Tab1ToolStripMenuItem2
        '
        Me.Tab1ToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menupagetitle1})
        Me.Tab1ToolStripMenuItem2.Name = "Tab1ToolStripMenuItem2"
        Me.Tab1ToolStripMenuItem2.Size = New System.Drawing.Size(100, 22)
        Me.Tab1ToolStripMenuItem2.Text = "Tab1"
        '
        'menupagetitle1
        '
        Me.menupagetitle1.Name = "menupagetitle1"
        Me.menupagetitle1.Size = New System.Drawing.Size(80, 22)
        Me.menupagetitle1.Text = "0"
        '
        'Tab2ToolStripMenuItem3
        '
        Me.Tab2ToolStripMenuItem3.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menupagetitle2})
        Me.Tab2ToolStripMenuItem3.Name = "Tab2ToolStripMenuItem3"
        Me.Tab2ToolStripMenuItem3.Size = New System.Drawing.Size(100, 22)
        Me.Tab2ToolStripMenuItem3.Text = "Tab2"
        '
        'menupagetitle2
        '
        Me.menupagetitle2.Name = "menupagetitle2"
        Me.menupagetitle2.Size = New System.Drawing.Size(80, 22)
        Me.menupagetitle2.Text = "0"
        '
        'WebpathToolStripMenuItem
        '
        Me.WebpathToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Tab1ToolStripMenuItem3, Me.Tab2ToolStripMenuItem4})
        Me.WebpathToolStripMenuItem.Name = "WebpathToolStripMenuItem"
        Me.WebpathToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.WebpathToolStripMenuItem.Text = "Webpath"
        '
        'Tab1ToolStripMenuItem3
        '
        Me.Tab1ToolStripMenuItem3.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuwebpath1})
        Me.Tab1ToolStripMenuItem3.Name = "Tab1ToolStripMenuItem3"
        Me.Tab1ToolStripMenuItem3.Size = New System.Drawing.Size(100, 22)
        Me.Tab1ToolStripMenuItem3.Text = "Tab1"
        '
        'menuwebpath1
        '
        Me.menuwebpath1.Name = "menuwebpath1"
        Me.menuwebpath1.Size = New System.Drawing.Size(80, 22)
        Me.menuwebpath1.Text = "0"
        '
        'Tab2ToolStripMenuItem4
        '
        Me.Tab2ToolStripMenuItem4.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuwebpath2})
        Me.Tab2ToolStripMenuItem4.Name = "Tab2ToolStripMenuItem4"
        Me.Tab2ToolStripMenuItem4.Size = New System.Drawing.Size(100, 22)
        Me.Tab2ToolStripMenuItem4.Text = "Tab2"
        '
        'menuwebpath2
        '
        Me.menuwebpath2.Name = "menuwebpath2"
        Me.menuwebpath2.Size = New System.Drawing.Size(80, 22)
        Me.menuwebpath2.Text = "0"
        '
        'ViewHTMLCodeToolStripMenuItem
        '
        Me.ViewHTMLCodeToolStripMenuItem.Name = "ViewHTMLCodeToolStripMenuItem"
        Me.ViewHTMLCodeToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.ViewHTMLCodeToolStripMenuItem.Text = "View HTML Code"
        '
        'SystemInfoToolStripMenuItem
        '
        Me.SystemInfoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OSNameToolStripMenuItem, Me.ArchitectureToolStripMenuItem, Me.ComputerNameToolStripMenuItem, Me.MemoryToolStripMenuItem})
        Me.SystemInfoToolStripMenuItem.Name = "SystemInfoToolStripMenuItem"
        Me.SystemInfoToolStripMenuItem.Size = New System.Drawing.Size(136, 22)
        Me.SystemInfoToolStripMenuItem.Text = "System Info"
        '
        'OSNameToolStripMenuItem
        '
        Me.OSNameToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuOSName})
        Me.OSNameToolStripMenuItem.Name = "OSNameToolStripMenuItem"
        Me.OSNameToolStripMenuItem.Size = New System.Drawing.Size(161, 22)
        Me.OSNameToolStripMenuItem.Text = "OS Name"
        '
        'menuOSName
        '
        Me.menuOSName.Name = "menuOSName"
        Me.menuOSName.Size = New System.Drawing.Size(80, 22)
        Me.menuOSName.Text = "0"
        '
        'ArchitectureToolStripMenuItem
        '
        Me.ArchitectureToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menubitcount})
        Me.ArchitectureToolStripMenuItem.Name = "ArchitectureToolStripMenuItem"
        Me.ArchitectureToolStripMenuItem.Size = New System.Drawing.Size(161, 22)
        Me.ArchitectureToolStripMenuItem.Text = "Architecture"
        '
        'menubitcount
        '
        Me.menubitcount.Name = "menubitcount"
        Me.menubitcount.Size = New System.Drawing.Size(80, 22)
        Me.menubitcount.Text = "0"
        '
        'ComputerNameToolStripMenuItem
        '
        Me.ComputerNameToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menucomputername})
        Me.ComputerNameToolStripMenuItem.Name = "ComputerNameToolStripMenuItem"
        Me.ComputerNameToolStripMenuItem.Size = New System.Drawing.Size(161, 22)
        Me.ComputerNameToolStripMenuItem.Text = "Computer name"
        '
        'menucomputername
        '
        Me.menucomputername.Name = "menucomputername"
        Me.menucomputername.Size = New System.Drawing.Size(80, 22)
        Me.menucomputername.Text = "0"
        Me.menucomputername.ToolTipText = "Displays the name of the computer"
        '
        'MemoryToolStripMenuItem
        '
        Me.MemoryToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AvailableRAMInstalledToolStripMenuItem, Me.FreeRAMAvailableToolStripMenuItem})
        Me.MemoryToolStripMenuItem.Name = "MemoryToolStripMenuItem"
        Me.MemoryToolStripMenuItem.Size = New System.Drawing.Size(161, 22)
        Me.MemoryToolStripMenuItem.Text = "Memory"
        '
        'AvailableRAMInstalledToolStripMenuItem
        '
        Me.AvailableRAMInstalledToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuRAM})
        Me.AvailableRAMInstalledToolStripMenuItem.Name = "AvailableRAMInstalledToolStripMenuItem"
        Me.AvailableRAMInstalledToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
        Me.AvailableRAMInstalledToolStripMenuItem.Text = "Available RAM installed"
        '
        'menuRAM
        '
        Me.menuRAM.Name = "menuRAM"
        Me.menuRAM.Size = New System.Drawing.Size(80, 22)
        Me.menuRAM.Text = "0"
        '
        'FreeRAMAvailableToolStripMenuItem
        '
        Me.FreeRAMAvailableToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menufreeRAM})
        Me.FreeRAMAvailableToolStripMenuItem.Name = "FreeRAMAvailableToolStripMenuItem"
        Me.FreeRAMAvailableToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
        Me.FreeRAMAvailableToolStripMenuItem.Text = "Free RAM available"
        '
        'menufreeRAM
        '
        Me.menufreeRAM.Name = "menufreeRAM"
        Me.menufreeRAM.Size = New System.Drawing.Size(80, 22)
        Me.menufreeRAM.Text = "0"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutTheBrowserToolStripMenuItem, Me.EngineTridentToolStripMenuItem, Me.ContributorsToolStripMenuItem})
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(136, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'AboutTheBrowserToolStripMenuItem
        '
        Me.AboutTheBrowserToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LeaderboardWebBrowser14Beta4Forkshaft4ToolStripMenuItem, Me.Build96ToolStripMenuItem, Me.Version1474ToolStripMenuItem})
        Me.AboutTheBrowserToolStripMenuItem.Name = "AboutTheBrowserToolStripMenuItem"
        Me.AboutTheBrowserToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.AboutTheBrowserToolStripMenuItem.Text = "About the browser"
        '
        'LeaderboardWebBrowser14Beta4Forkshaft4ToolStripMenuItem
        '
        Me.LeaderboardWebBrowser14Beta4Forkshaft4ToolStripMenuItem.Name = "LeaderboardWebBrowser14Beta4Forkshaft4ToolStripMenuItem"
        Me.LeaderboardWebBrowser14Beta4Forkshaft4ToolStripMenuItem.Size = New System.Drawing.Size(326, 22)
        Me.LeaderboardWebBrowser14Beta4Forkshaft4ToolStripMenuItem.Text = "Leaderboard Web browser 1.4 Beta 4 Forkshaft 4"
        '
        'Build96ToolStripMenuItem
        '
        Me.Build96ToolStripMenuItem.Name = "Build96ToolStripMenuItem"
        Me.Build96ToolStripMenuItem.Size = New System.Drawing.Size(326, 22)
        Me.Build96ToolStripMenuItem.Text = "Build 96"
        '
        'Version1474ToolStripMenuItem
        '
        Me.Version1474ToolStripMenuItem.Name = "Version1474ToolStripMenuItem"
        Me.Version1474ToolStripMenuItem.Size = New System.Drawing.Size(326, 22)
        Me.Version1474ToolStripMenuItem.Text = "Version - 1.4.7.4"
        '
        'EngineTridentToolStripMenuItem
        '
        Me.EngineTridentToolStripMenuItem.Name = "EngineTridentToolStripMenuItem"
        Me.EngineTridentToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.EngineTridentToolStripMenuItem.Text = "Engine - Trident"
        '
        'ContributorsToolStripMenuItem
        '
        Me.ContributorsToolStripMenuItem.Name = "ContributorsToolStripMenuItem"
        Me.ContributorsToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.ContributorsToolStripMenuItem.Text = "Contributors"
        '
        'PageOptionsToolStripMenuItem
        '
        Me.PageOptionsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GoBackToolStripMenuItem, Me.GoForwardToolStripMenuItem, Me.RefreshToolStripMenuItem, Me.StopToolStripMenuItem, Me.HomeToolStripMenuItem, Me.GoToPageToolStripMenuItem, Me.ToolStripTextBox1})
        Me.PageOptionsToolStripMenuItem.Name = "PageOptionsToolStripMenuItem"
        Me.PageOptionsToolStripMenuItem.Size = New System.Drawing.Size(69, 20)
        Me.PageOptionsToolStripMenuItem.Text = "&Webpage"
        Me.PageOptionsToolStripMenuItem.ToolTipText = "Goes to the previous webpage"
        '
        'GoBackToolStripMenuItem
        '
        Me.GoBackToolStripMenuItem.Name = "GoBackToolStripMenuItem"
        Me.GoBackToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.GoBackToolStripMenuItem.Text = "&Go back"
        Me.GoBackToolStripMenuItem.ToolTipText = "Goes to the previous page."
        '
        'GoForwardToolStripMenuItem
        '
        Me.GoForwardToolStripMenuItem.Name = "GoForwardToolStripMenuItem"
        Me.GoForwardToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.GoForwardToolStripMenuItem.Text = "G&o forward "
        Me.GoForwardToolStripMenuItem.ToolTipText = "Goes to the next webpage."
        '
        'RefreshToolStripMenuItem
        '
        Me.RefreshToolStripMenuItem.Name = "RefreshToolStripMenuItem"
        Me.RefreshToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.RefreshToolStripMenuItem.Text = "&Refresh"
        Me.RefreshToolStripMenuItem.ToolTipText = "Refreshes the page."
        '
        'StopToolStripMenuItem
        '
        Me.StopToolStripMenuItem.Image = CType(resources.GetObject("StopToolStripMenuItem.Image"), System.Drawing.Image)
        Me.StopToolStripMenuItem.Name = "StopToolStripMenuItem"
        Me.StopToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.StopToolStripMenuItem.Text = "&Stop"
        Me.StopToolStripMenuItem.ToolTipText = "Stops the page from being viewed."
        '
        'HomeToolStripMenuItem
        '
        Me.HomeToolStripMenuItem.Name = "HomeToolStripMenuItem"
        Me.HomeToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.HomeToolStripMenuItem.Text = "&Home"
        Me.HomeToolStripMenuItem.ToolTipText = "Loads your Home page."
        '
        'GoToPageToolStripMenuItem
        '
        Me.GoToPageToolStripMenuItem.Name = "GoToPageToolStripMenuItem"
        Me.GoToPageToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.GoToPageToolStripMenuItem.Text = "Go &to page"
        Me.GoToPageToolStripMenuItem.ToolTipText = "Loads the specified page. Note: The Address bar is at the bottom of the Webpage m" & _
    "enu and will work only with this button."
        '
        'ToolStripTextBox1
        '
        Me.ToolStripTextBox1.Name = "ToolStripTextBox1"
        Me.ToolStripTextBox1.Size = New System.Drawing.Size(100, 23)
        Me.ToolStripTextBox1.ToolTipText = "The Address bar. It will work only with the Go to page button in the Webpage menu" & _
    "."
        '
        'BackgroundToolStripMenuItem
        '
        Me.BackgroundToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MankYourOwnMessageBoxToolStripMenuItem, Me.ClearTheWebpageToolStripMenuItem, Me.PrintAPageToolStripMenuItem, Me.DisableScriptingErrorsToolStripMenuItem, Me.BlenderToolStripMenuItem})
        Me.BackgroundToolStripMenuItem.Name = "BackgroundToolStripMenuItem"
        Me.BackgroundToolStripMenuItem.Size = New System.Drawing.Size(48, 20)
        Me.BackgroundToolStripMenuItem.Text = "Tools"
        '
        'MankYourOwnMessageBoxToolStripMenuItem
        '
        Me.MankYourOwnMessageBoxToolStripMenuItem.Name = "MankYourOwnMessageBoxToolStripMenuItem"
        Me.MankYourOwnMessageBoxToolStripMenuItem.Size = New System.Drawing.Size(227, 22)
        Me.MankYourOwnMessageBoxToolStripMenuItem.Text = "Make yo&ur own message box"
        Me.MankYourOwnMessageBoxToolStripMenuItem.ToolTipText = "Helps you to make your own message box"
        '
        'ClearTheWebpageToolStripMenuItem
        '
        Me.ClearTheWebpageToolStripMenuItem.Name = "ClearTheWebpageToolStripMenuItem"
        Me.ClearTheWebpageToolStripMenuItem.Size = New System.Drawing.Size(227, 22)
        Me.ClearTheWebpageToolStripMenuItem.Text = "Clear the webpage"
        Me.ClearTheWebpageToolStripMenuItem.ToolTipText = "Clears everything on the webpage"
        '
        'PrintAPageToolStripMenuItem
        '
        Me.PrintAPageToolStripMenuItem.Name = "PrintAPageToolStripMenuItem"
        Me.PrintAPageToolStripMenuItem.Size = New System.Drawing.Size(227, 22)
        Me.PrintAPageToolStripMenuItem.Text = "Print a page"
        Me.PrintAPageToolStripMenuItem.ToolTipText = "Allows you to print a page."
        '
        'DisableScriptingErrorsToolStripMenuItem
        '
        Me.DisableScriptingErrorsToolStripMenuItem.Name = "DisableScriptingErrorsToolStripMenuItem"
        Me.DisableScriptingErrorsToolStripMenuItem.Size = New System.Drawing.Size(227, 22)
        Me.DisableScriptingErrorsToolStripMenuItem.Text = "Disable Scripting errors"
        '
        'BlenderToolStripMenuItem
        '
        Me.BlenderToolStripMenuItem.Name = "BlenderToolStripMenuItem"
        Me.BlenderToolStripMenuItem.Size = New System.Drawing.Size(227, 22)
        Me.BlenderToolStripMenuItem.Text = "Blender"
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RibbonToolStripMenuItem, Me.TipsToolStripMenuItem, Me.MenuColourOptionsToolStripMenuItem, Me.SetHomePageToolStripMenuItem, Me.AdvancedWebSettingsToolStripMenuItem, Me.ChangeSearchBaseEngineToolStripMenuItem})
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(61, 20)
        Me.ToolsToolStripMenuItem.Text = "Options"
        '
        'RibbonToolStripMenuItem
        '
        Me.RibbonToolStripMenuItem.Name = "RibbonToolStripMenuItem"
        Me.RibbonToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.RibbonToolStripMenuItem.Text = "Ribbon/Menu Options"
        Me.RibbonToolStripMenuItem.ToolTipText = "Switches between the Ribbon and menu modes"
        '
        'TipsToolStripMenuItem
        '
        Me.TipsToolStripMenuItem.Name = "TipsToolStripMenuItem"
        Me.TipsToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.TipsToolStripMenuItem.Text = "Tip options"
        Me.TipsToolStripMenuItem.ToolTipText = "Sets options for Tips"
        '
        'MenuColourOptionsToolStripMenuItem
        '
        Me.MenuColourOptionsToolStripMenuItem.Name = "MenuColourOptionsToolStripMenuItem"
        Me.MenuColourOptionsToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.MenuColourOptionsToolStripMenuItem.Text = "Menu Colour options"
        Me.MenuColourOptionsToolStripMenuItem.ToolTipText = "Changes the colour of the Menu bar"
        '
        'SetHomePageToolStripMenuItem
        '
        Me.SetHomePageToolStripMenuItem.Name = "SetHomePageToolStripMenuItem"
        Me.SetHomePageToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.SetHomePageToolStripMenuItem.Text = "Set home page"
        '
        'AdvancedWebSettingsToolStripMenuItem
        '
        Me.AdvancedWebSettingsToolStripMenuItem.Name = "AdvancedWebSettingsToolStripMenuItem"
        Me.AdvancedWebSettingsToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.AdvancedWebSettingsToolStripMenuItem.Text = "Advanced Web Settings"
        '
        'ChangeSearchBaseEngineToolStripMenuItem
        '
        Me.ChangeSearchBaseEngineToolStripMenuItem.Name = "ChangeSearchBaseEngineToolStripMenuItem"
        Me.ChangeSearchBaseEngineToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.ChangeSearchBaseEngineToolStripMenuItem.Text = "Change SearchBase engine"
        '
        'HistoryFavouritesToolStripMenuItem
        '
        Me.HistoryFavouritesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HistoryToolStripMenuItem1, Me.SearchBaseToolStripMenuItem, Me.FavouritesToolStripMenuItem, Me.ActivateSearchBarToolStripMenuItem, Me.AddFavouritesToolStripMenuItem})
        Me.HistoryFavouritesToolStripMenuItem.Name = "HistoryFavouritesToolStripMenuItem"
        Me.HistoryFavouritesToolStripMenuItem.Size = New System.Drawing.Size(116, 20)
        Me.HistoryFavouritesToolStripMenuItem.Text = "History/Favourites"
        '
        'HistoryToolStripMenuItem1
        '
        Me.HistoryToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuhistory})
        Me.HistoryToolStripMenuItem1.Name = "HistoryToolStripMenuItem1"
        Me.HistoryToolStripMenuItem1.Size = New System.Drawing.Size(175, 22)
        Me.HistoryToolStripMenuItem1.Text = "History"
        '
        'menuhistory
        '
        Me.menuhistory.Name = "menuhistory"
        Me.menuhistory.Size = New System.Drawing.Size(121, 23)
        '
        'SearchBaseToolStripMenuItem
        '
        Me.SearchBaseToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuhistorysearch})
        Me.SearchBaseToolStripMenuItem.Name = "SearchBaseToolStripMenuItem"
        Me.SearchBaseToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.SearchBaseToolStripMenuItem.Text = "SearchBase"
        '
        'menuhistorysearch
        '
        Me.menuhistorysearch.Name = "menuhistorysearch"
        Me.menuhistorysearch.Size = New System.Drawing.Size(121, 23)
        '
        'FavouritesToolStripMenuItem
        '
        Me.FavouritesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menufavourties})
        Me.FavouritesToolStripMenuItem.Name = "FavouritesToolStripMenuItem"
        Me.FavouritesToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.FavouritesToolStripMenuItem.Text = "Favourites"
        '
        'menufavourties
        '
        Me.menufavourties.Name = "menufavourties"
        Me.menufavourties.Size = New System.Drawing.Size(121, 23)
        '
        'ActivateSearchBarToolStripMenuItem
        '
        Me.ActivateSearchBarToolStripMenuItem.Name = "ActivateSearchBarToolStripMenuItem"
        Me.ActivateSearchBarToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.ActivateSearchBarToolStripMenuItem.Text = "Activate Search Bar"
        '
        'AddFavouritesToolStripMenuItem
        '
        Me.AddFavouritesToolStripMenuItem.Name = "AddFavouritesToolStripMenuItem"
        Me.AddFavouritesToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.AddFavouritesToolStripMenuItem.Text = "Add Favourites"
        '
        'DisplayStripMenuItem
        '
        Me.DisplayStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ResizingToolStripMenuItem, Me.MainTitleToolStripMenuItem, Me.DefaultMaximizeMinimizeToolStripMenuItem})
        Me.DisplayStripMenuItem.Name = "DisplayStripMenuItem"
        Me.DisplayStripMenuItem.Size = New System.Drawing.Size(57, 20)
        Me.DisplayStripMenuItem.Text = "Display"
        '
        'ResizingToolStripMenuItem
        '
        Me.ResizingToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DisableToolStripMenuItem, Me.EnableToolStripMenuItem})
        Me.ResizingToolStripMenuItem.Name = "ResizingToolStripMenuItem"
        Me.ResizingToolStripMenuItem.Size = New System.Drawing.Size(219, 22)
        Me.ResizingToolStripMenuItem.Text = "Resizing"
        '
        'DisableToolStripMenuItem
        '
        Me.DisableToolStripMenuItem.Name = "DisableToolStripMenuItem"
        Me.DisableToolStripMenuItem.Size = New System.Drawing.Size(112, 22)
        Me.DisableToolStripMenuItem.Text = "Disable"
        '
        'EnableToolStripMenuItem
        '
        Me.EnableToolStripMenuItem.Name = "EnableToolStripMenuItem"
        Me.EnableToolStripMenuItem.Size = New System.Drawing.Size(112, 22)
        Me.EnableToolStripMenuItem.Text = "Enable"
        '
        'MainTitleToolStripMenuItem
        '
        Me.MainTitleToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DisableToolStripMenuItem1, Me.EnableToolStripMenuItem1})
        Me.MainTitleToolStripMenuItem.Name = "MainTitleToolStripMenuItem"
        Me.MainTitleToolStripMenuItem.Size = New System.Drawing.Size(219, 22)
        Me.MainTitleToolStripMenuItem.Text = "Main title"
        '
        'DisableToolStripMenuItem1
        '
        Me.DisableToolStripMenuItem1.Name = "DisableToolStripMenuItem1"
        Me.DisableToolStripMenuItem1.Size = New System.Drawing.Size(112, 22)
        Me.DisableToolStripMenuItem1.Text = "Disable"
        '
        'EnableToolStripMenuItem1
        '
        Me.EnableToolStripMenuItem1.Name = "EnableToolStripMenuItem1"
        Me.EnableToolStripMenuItem1.Size = New System.Drawing.Size(112, 22)
        Me.EnableToolStripMenuItem1.Text = "Enable"
        '
        'DefaultMaximizeMinimizeToolStripMenuItem
        '
        Me.DefaultMaximizeMinimizeToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DisableToolStripMenuItem2, Me.EnableToolStripMenuItem2})
        Me.DefaultMaximizeMinimizeToolStripMenuItem.Name = "DefaultMaximizeMinimizeToolStripMenuItem"
        Me.DefaultMaximizeMinimizeToolStripMenuItem.Size = New System.Drawing.Size(219, 22)
        Me.DefaultMaximizeMinimizeToolStripMenuItem.Text = "Default Maximize/Minimize"
        '
        'DisableToolStripMenuItem2
        '
        Me.DisableToolStripMenuItem2.Name = "DisableToolStripMenuItem2"
        Me.DisableToolStripMenuItem2.Size = New System.Drawing.Size(112, 22)
        Me.DisableToolStripMenuItem2.Text = "Disable"
        '
        'EnableToolStripMenuItem2
        '
        Me.EnableToolStripMenuItem2.Name = "EnableToolStripMenuItem2"
        Me.EnableToolStripMenuItem2.Size = New System.Drawing.Size(112, 22)
        Me.EnableToolStripMenuItem2.Text = "Enable"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuHelpAbout, Me.RerunFirstRunWizardToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "He&lp"
        '
        'mnuHelpAbout
        '
        Me.mnuHelpAbout.Name = "mnuHelpAbout"
        Me.mnuHelpAbout.Size = New System.Drawing.Size(193, 22)
        Me.mnuHelpAbout.Text = "&About"
        Me.mnuHelpAbout.ToolTipText = "Displays info about this application"
        '
        'RerunFirstRunWizardToolStripMenuItem
        '
        Me.RerunFirstRunWizardToolStripMenuItem.Name = "RerunFirstRunWizardToolStripMenuItem"
        Me.RerunFirstRunWizardToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.RerunFirstRunWizardToolStripMenuItem.Text = "Rerun First Run Wizard"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CloseToolStripMenuItem})
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.ExitToolStripMenuItem.Text = "E&xit"
        '
        'CloseToolStripMenuItem
        '
        Me.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem"
        Me.CloseToolStripMenuItem.Size = New System.Drawing.Size(103, 22)
        Me.CloseToolStripMenuItem.Text = "&Close"
        Me.CloseToolStripMenuItem.ToolTipText = "Closes the browser."
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 448)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(783, 22)
        Me.StatusStrip1.TabIndex = 2
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(39, 17)
        Me.ToolStripStatusLabel1.Text = "Status"
        '
        'PerformanceCounter1
        '
        Me.PerformanceCounter1.CategoryName = ".NET CLR Memory"
        Me.PerformanceCounter1.CounterName = "% Time in GC"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 250
        '
        'Timer3
        '
        Me.Timer3.Interval = 200
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.TabControl3)
        Me.Panel2.Controls.Add(Me.Button20)
        Me.Panel2.Controls.Add(Me.TabControl2)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Enabled = False
        Me.Panel2.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.Panel2.Location = New System.Drawing.Point(0, 93)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(783, 355)
        Me.Panel2.TabIndex = 3
        '
        'TabControl3
        '
        Me.TabControl3.Controls.Add(Me.TabPage13)
        Me.TabControl3.Controls.Add(Me.TabPage12)
        Me.TabControl3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl3.Location = New System.Drawing.Point(0, 0)
        Me.TabControl3.Name = "TabControl3"
        Me.TabControl3.SelectedIndex = 0
        Me.TabControl3.Size = New System.Drawing.Size(783, 355)
        Me.TabControl3.TabIndex = 5
        '
        'TabPage13
        '
        Me.TabPage13.Controls.Add(Me.Webbrowser2)
        Me.TabPage13.Controls.Add(Me.WebBrowser2a)
        Me.TabPage13.Location = New System.Drawing.Point(4, 23)
        Me.TabPage13.Name = "TabPage13"
        Me.TabPage13.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage13.Size = New System.Drawing.Size(775, 328)
        Me.TabPage13.TabIndex = 1
        Me.TabPage13.Text = "Tab1"
        Me.TabPage13.UseVisualStyleBackColor = True
        '
        'Webbrowser2
        '
        Me.Webbrowser2.Location = New System.Drawing.Point(-6, -2)
        Me.Webbrowser2.Name = "Webbrowser2"
        Me.Webbrowser2.Size = New System.Drawing.Size(782, 334)
        Me.Webbrowser2.TabIndex = 1
        '
        'WebBrowser2a
        '
        Me.WebBrowser2a.Dock = System.Windows.Forms.DockStyle.Fill
        Me.WebBrowser2a.Location = New System.Drawing.Point(3, 3)
        Me.WebBrowser2a.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser2a.Name = "WebBrowser2a"
        Me.WebBrowser2a.Size = New System.Drawing.Size(769, 322)
        Me.WebBrowser2a.TabIndex = 0
        '
        'TabPage12
        '
        Me.TabPage12.Controls.Add(Me.WebBrowser1)
        Me.TabPage12.Location = New System.Drawing.Point(4, 23)
        Me.TabPage12.Name = "TabPage12"
        Me.TabPage12.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage12.Size = New System.Drawing.Size(775, 328)
        Me.TabPage12.TabIndex = 0
        Me.TabPage12.Text = "Tab2"
        Me.TabPage12.UseVisualStyleBackColor = True
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.WebBrowser1.Location = New System.Drawing.Point(3, 3)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.Size = New System.Drawing.Size(769, 322)
        Me.WebBrowser1.TabIndex = 0
        Me.WebBrowser1.Url = New System.Uri("", System.UriKind.Relative)
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage7)
        Me.TabControl2.Controls.Add(Me.TabPage6)
        Me.TabControl2.Controls.Add(Me.TabPage8)
        Me.TabControl2.Controls.Add(Me.TabPage9)
        Me.TabControl2.Location = New System.Drawing.Point(3, 53)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(780, 275)
        Me.TabControl2.TabIndex = 4
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.Label39)
        Me.TabPage7.Controls.Add(Me.GroupBox12)
        Me.TabPage7.Controls.Add(Me.Button24)
        Me.TabPage7.Controls.Add(Me.ShapeContainer1)
        Me.TabPage7.Location = New System.Drawing.Point(4, 23)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(772, 248)
        Me.TabPage7.TabIndex = 2
        Me.TabPage7.Text = "Home"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(3, 12)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(39, 16)
        Me.Label39.TabIndex = 2
        Me.Label39.Text = "TIME"
        '
        'GroupBox12
        '
        Me.GroupBox12.Controls.Add(Me.pinapp_2)
        Me.GroupBox12.Controls.Add(Me.pinapp_1)
        Me.GroupBox12.Location = New System.Drawing.Point(209, 0)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Size = New System.Drawing.Size(560, 248)
        Me.GroupBox12.TabIndex = 1
        Me.GroupBox12.TabStop = False
        Me.GroupBox12.Text = "Pinned apps"
        '
        'pinapp_2
        '
        Me.pinapp_2.Location = New System.Drawing.Point(87, 19)
        Me.pinapp_2.Name = "pinapp_2"
        Me.pinapp_2.Size = New System.Drawing.Size(80, 44)
        Me.pinapp_2.TabIndex = 1
        Me.pinapp_2.Text = "app_2"
        Me.pinapp_2.UseVisualStyleBackColor = True
        '
        'pinapp_1
        '
        Me.pinapp_1.Location = New System.Drawing.Point(0, 20)
        Me.pinapp_1.Name = "pinapp_1"
        Me.pinapp_1.Size = New System.Drawing.Size(90, 43)
        Me.pinapp_1.TabIndex = 0
        Me.pinapp_1.Text = "app_1"
        Me.pinapp_1.UseVisualStyleBackColor = True
        '
        'Button24
        '
        Me.Button24.Location = New System.Drawing.Point(9, 78)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(135, 60)
        Me.Button24.TabIndex = 0
        Me.Button24.Text = "App store(pre release)"
        Me.Button24.UseVisualStyleBackColor = True
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(3, 3)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.LineShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(766, 242)
        Me.ShapeContainer1.TabIndex = 3
        Me.ShapeContainer1.TabStop = False
        '
        'LineShape1
        '
        Me.LineShape1.Name = "LineShape1"
        Me.LineShape1.X1 = 0
        Me.LineShape1.X2 = 210
        Me.LineShape1.Y1 = 47
        Me.LineShape1.Y2 = 47
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.Label46)
        Me.TabPage6.Controls.Add(Me.Label45)
        Me.TabPage6.Controls.Add(Me.Label44)
        Me.TabPage6.Controls.Add(Me.Label43)
        Me.TabPage6.Controls.Add(Me.Label42)
        Me.TabPage6.Controls.Add(Me.Label41)
        Me.TabPage6.Controls.Add(Me.Label40)
        Me.TabPage6.Controls.Add(Me.Label18)
        Me.TabPage6.Controls.Add(Me.Label17)
        Me.TabPage6.Controls.Add(Me.Button21)
        Me.TabPage6.Controls.Add(Me.Label10)
        Me.TabPage6.Controls.Add(Me.Label9)
        Me.TabPage6.Controls.Add(Me.Label8)
        Me.TabPage6.Controls.Add(Me.Label7)
        Me.TabPage6.Controls.Add(Me.Label6)
        Me.TabPage6.Controls.Add(Me.Label5)
        Me.TabPage6.Controls.Add(Me.Label4)
        Me.TabPage6.Controls.Add(Me.Label3)
        Me.TabPage6.Controls.Add(Me.ShapeContainer2)
        Me.TabPage6.Location = New System.Drawing.Point(4, 23)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(772, 248)
        Me.TabPage6.TabIndex = 1
        Me.TabPage6.Text = "Web info"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(537, 133)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(37, 14)
        Me.Label46.TabIndex = 18
        Me.Label46.Text = "(level)"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(534, 103)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(36, 14)
        Me.Label45.TabIndex = 17
        Me.Label45.Text = "(type)"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(534, 77)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(36, 14)
        Me.Label44.TabIndex = 16
        Me.Label44.Text = "(path)"
        '
        'Label43
        '
        Me.Label43.Location = New System.Drawing.Point(534, 53)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(237, 23)
        Me.Label43.TabIndex = 15
        Me.Label43.Text = "(webdomain)"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(534, 17)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(52, 14)
        Me.Label42.TabIndex = 14
        Me.Label42.Text = "unknown"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(552, 3)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(32, 14)
        Me.Label41.TabIndex = 13
        Me.Label41.Text = "Tab2"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(289, 3)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(32, 14)
        Me.Label40.TabIndex = 12
        Me.Label40.Text = "Tab1"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(282, 133)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(37, 14)
        Me.Label18.TabIndex = 10
        Me.Label18.Text = "(level)"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(6, 133)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(83, 14)
        Me.Label17.TabIndex = 9
        Me.Label17.Text = "Encrpytion level"
        '
        'Button21
        '
        Me.Button21.Location = New System.Drawing.Point(3, 216)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(137, 31)
        Me.Button21.TabIndex = 8
        Me.Button21.Text = "View HTML Code"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(283, 103)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(36, 14)
        Me.Label10.TabIndex = 7
        Me.Label10.Text = "(type)"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(6, 103)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(93, 14)
        Me.Label9.TabIndex = 6
        Me.Label9.Text = "Type of document"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(285, 77)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(36, 14)
        Me.Label8.TabIndex = 5
        Me.Label8.Text = "(path)"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(5, 77)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(28, 14)
        Me.Label7.TabIndex = 4
        Me.Label7.Text = "Path"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(285, 53)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(218, 23)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "(webdomain)"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 53)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(90, 14)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Webpage domain"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(3, 27)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(209, 14)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Title of the page you are visiting right now"
        '
        'ShapeContainer2
        '
        Me.ShapeContainer2.Location = New System.Drawing.Point(3, 3)
        Me.ShapeContainer2.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer2.Name = "ShapeContainer2"
        Me.ShapeContainer2.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.LineShape3, Me.LineShape2})
        Me.ShapeContainer2.Size = New System.Drawing.Size(766, 242)
        Me.ShapeContainer2.TabIndex = 11
        Me.ShapeContainer2.TabStop = False
        '
        'LineShape3
        '
        Me.LineShape3.Name = "LineShape3"
        Me.LineShape3.X1 = 280
        Me.LineShape3.X2 = 770
        Me.LineShape3.Y1 = 14
        Me.LineShape3.Y2 = 12
        '
        'LineShape2
        '
        Me.LineShape2.Name = "LineShape2"
        Me.LineShape2.X1 = 279
        Me.LineShape2.X2 = 278
        Me.LineShape2.Y1 = -4
        Me.LineShape2.Y2 = 247
        '
        'TabPage8
        '
        Me.TabPage8.Controls.Add(Me.Label50)
        Me.TabPage8.Controls.Add(Me.Label49)
        Me.TabPage8.Controls.Add(Me.Label38)
        Me.TabPage8.Controls.Add(Me.GroupBox14)
        Me.TabPage8.Controls.Add(Me.Label35)
        Me.TabPage8.Controls.Add(Me.Label34)
        Me.TabPage8.Controls.Add(Me.Label33)
        Me.TabPage8.Controls.Add(Me.Label32)
        Me.TabPage8.Controls.Add(Me.ProgressBar1)
        Me.TabPage8.Controls.Add(Me.Label31)
        Me.TabPage8.Controls.Add(Me.Label30)
        Me.TabPage8.Controls.Add(Me.Label29)
        Me.TabPage8.Controls.Add(Me.Label28)
        Me.TabPage8.Controls.Add(Me.Label27)
        Me.TabPage8.Controls.Add(Me.Label26)
        Me.TabPage8.Controls.Add(Me.Label25)
        Me.TabPage8.Controls.Add(Me.Label24)
        Me.TabPage8.Controls.Add(Me.Label23)
        Me.TabPage8.Controls.Add(Me.Label22)
        Me.TabPage8.Controls.Add(Me.Label21)
        Me.TabPage8.Controls.Add(Me.Label20)
        Me.TabPage8.Controls.Add(Me.Label19)
        Me.TabPage8.Controls.Add(Me.PictureBox2)
        Me.TabPage8.Location = New System.Drawing.Point(4, 23)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(772, 248)
        Me.TabPage8.TabIndex = 3
        Me.TabPage8.Text = "System info"
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(549, 68)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(45, 14)
        Me.Label50.TabIndex = 22
        Me.Label50.Text = "Label50"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.Location = New System.Drawing.Point(425, 68)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(81, 14)
        Me.Label49.TabIndex = 21
        Me.Label49.Text = "Power status"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(80, 7)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(99, 19)
        Me.Label38.TabIndex = 20
        Me.Label38.Text = "(UserName)"
        '
        'GroupBox14
        '
        Me.GroupBox14.Controls.Add(Me.Label37)
        Me.GroupBox14.Controls.Add(Me.Label36)
        Me.GroupBox14.Location = New System.Drawing.Point(425, 2)
        Me.GroupBox14.Name = "GroupBox14"
        Me.GroupBox14.Size = New System.Drawing.Size(319, 55)
        Me.GroupBox14.TabIndex = 18
        Me.GroupBox14.TabStop = False
        Me.GroupBox14.Text = "Network"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(121, 20)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(72, 14)
        Me.Label37.TabIndex = 1
        Me.Label37.Text = "(connected?)"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(187, 208)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(22, 14)
        Me.Label35.TabIndex = 17
        Me.Label35.Text = "MB"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(187, 178)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(22, 14)
        Me.Label34.TabIndex = 16
        Me.Label34.Text = "MB"
        '
        'Label33
        '
        Me.Label33.Location = New System.Drawing.Point(240, 231)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(29, 11)
        Me.Label33.TabIndex = 15
        Me.Label33.Text = "x"
        '
        'Label32
        '
        Me.Label32.Location = New System.Drawing.Point(272, 231)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(24, 13)
        Me.Label32.TabIndex = 14
        Me.Label32.Text = "%"
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(131, 231)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(98, 14)
        Me.ProgressBar1.TabIndex = 13
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(-3, 231)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(72, 14)
        Me.Label31.TabIndex = 12
        Me.Label31.Text = "Free RAM %"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(1, 208)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(60, 14)
        Me.Label29.TabIndex = 10
        Me.Label29.Text = "Free RAM"
        '
        'Label28
        '
        Me.Label28.Location = New System.Drawing.Point(136, 178)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(40, 18)
        Me.Label28.TabIndex = 9
        Me.Label28.Text = "(RAMI)"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(1, 178)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(134, 14)
        Me.Label27.TabIndex = 8
        Me.Label27.Text = "Available RAM installed"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(136, 151)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(41, 14)
        Me.Label26.TabIndex = 7
        Me.Label26.Text = "(name)"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(1, 123)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(76, 14)
        Me.Label23.TabIndex = 4
        Me.Label23.Text = "Architecture"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(136, 96)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(51, 14)
        Me.Label22.TabIndex = 3
        Me.Label22.Text = "(version)"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(136, 68)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(41, 14)
        Me.Label20.TabIndex = 1
        Me.Label20.Text = "(name)"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(1, 68)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(56, 14)
        Me.Label19.TabIndex = 0
        Me.Label19.Text = "OS Name"
        '
        'PictureBox2
        '
        Me.PictureBox2.Location = New System.Drawing.Point(4, 7)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(70, 50)
        Me.PictureBox2.TabIndex = 19
        Me.PictureBox2.TabStop = False
        '
        'TabPage9
        '
        Me.TabPage9.Controls.Add(Me.GroupBox11)
        Me.TabPage9.Controls.Add(Me.Label2)
        Me.TabPage9.Controls.Add(Me.GroupBox10)
        Me.TabPage9.Controls.Add(Me.TableLayoutPanel1)
        Me.TabPage9.Controls.Add(Me.Label13)
        Me.TabPage9.Controls.Add(Me.Label12)
        Me.TabPage9.Controls.Add(Me.Label11)
        Me.TabPage9.Location = New System.Drawing.Point(4, 23)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage9.Size = New System.Drawing.Size(772, 248)
        Me.TabPage9.TabIndex = 4
        Me.TabPage9.Text = "About"
        Me.TabPage9.ToolTipText = "About - Dispays information about this browser."
        Me.TabPage9.UseVisualStyleBackColor = True
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.Label48)
        Me.GroupBox11.Controls.Add(Me.LinkLabel1)
        Me.GroupBox11.Controls.Add(Me.Label47)
        Me.GroupBox11.Location = New System.Drawing.Point(307, 116)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(200, 132)
        Me.GroupBox11.TabIndex = 6
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "Web site"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(0, 52)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(0, 14)
        Me.Label48.TabIndex = 2
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Location = New System.Drawing.Point(0, 24)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(166, 14)
        Me.LinkLabel1.TabIndex = 1
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "http://www.lead-board.com/web"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(0, 20)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(0, 14)
        Me.Label47.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 90)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(45, 14)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Build 96"
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.Label16)
        Me.GroupBox10.Controls.Add(Me.Label15)
        Me.GroupBox10.Controls.Add(Me.Label14)
        Me.GroupBox10.Location = New System.Drawing.Point(0, 116)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(301, 129)
        Me.GroupBox10.TabIndex = 4
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "Engine details"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(50, 52)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(22, 14)
        Me.Label16.TabIndex = 2
        Me.Label16.Text = "0.0"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(1, 52)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(54, 14)
        Me.Label15.TabIndex = 1
        Me.Label15.Text = "Version - "
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(3, 24)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(82, 14)
        Me.Label14.TabIndex = 0
        Me.Label14.Text = "Engine - Trident"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 81.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Button25, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Button34, 1, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(641, 3)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(134, 44)
        Me.TableLayoutPanel1.TabIndex = 3
        '
        'Button25
        '
        Me.Button25.Location = New System.Drawing.Point(3, 3)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(47, 38)
        Me.Button25.TabIndex = 0
        Me.Button25.Text = "About"
        Me.Button25.UseVisualStyleBackColor = True
        '
        'Button34
        '
        Me.Button34.Location = New System.Drawing.Point(56, 3)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(75, 38)
        Me.Button34.TabIndex = 1
        Me.Button34.Text = "Contributors"
        Me.Button34.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(6, 62)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(87, 14)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "Version - 1.4.7.4"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(6, 34)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(249, 14)
        Me.Label12.TabIndex = 1
        Me.Label12.Text = "Leaderboard Web browser 1.4 Beta 4 Forkshaft 4"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(4, 5)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(115, 14)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "About this browser"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(9, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(105, 14)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Ribbon Backstage"
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(61, 4)
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ClientSize = New System.Drawing.Size(783, 470)
        Me.Controls.Add(Me.GroupBox13)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HelpButton = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Leaderboard Web brower 1.4 Beta 4 Forkshaft 4(1.4.7.4)"
        Me.TransparencyKey = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox13.ResumeLayout(False)
        Me.GroupBox13.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage10.ResumeLayout(False)
        Me.GroupBox23.ResumeLayout(False)
        Me.GroupBox22.ResumeLayout(False)
        Me.GroupBox21.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.GroupBox20.ResumeLayout(False)
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        Me.TabPage11.ResumeLayout(False)
        Me.GroupBox17.ResumeLayout(False)
        Me.GroupBox16.ResumeLayout(False)
        Me.GroupBox15.ResumeLayout(False)
        Me.TabPage5.ResumeLayout(False)
        Me.GroupBox18.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.GroupBox19.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.GroupBox8.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        CType(Me.PerformanceCounter1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.TabControl3.ResumeLayout(False)
        Me.TabPage13.ResumeLayout(False)
        Me.TabPage12.ResumeLayout(False)
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage7.PerformLayout()
        Me.GroupBox12.ResumeLayout(False)
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        Me.TabPage8.ResumeLayout(False)
        Me.TabPage8.PerformLayout()
        Me.GroupBox14.ResumeLayout(False)
        Me.GroupBox14.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage9.ResumeLayout(False)
        Me.TabPage9.PerformLayout()
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ColorDialog1 As System.Windows.Forms.ColorDialog
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents NotifyIcon1 As System.Windows.Forms.NotifyIcon
    Friend WithEvents PrintDialog1 As System.Windows.Forms.PrintDialog
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents PageOptionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GoBackToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GoForwardToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RefreshToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StopToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HomeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GoToPageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripTextBox1 As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BackgroundToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MankYourOwnMessageBoxToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuHelpAbout As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CloseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClearTheWebpageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrintAPageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents PerformanceCounter1 As System.Diagnostics.PerformanceCounter
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents Button23 As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents MainToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HomeToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrereleaseAppStoreToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WebInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutTheBrowserToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabPage10 As System.Windows.Forms.TabPage
    Friend WithEvents ToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RibbonToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TipsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuColourOptionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WebpageTypeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EncryptionLevelToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WebpageDomainToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PageTitleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WebpathToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewHTMLCodeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DisableScriptingErrorsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents SystemInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OSNameToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuOSName As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Button27 As System.Windows.Forms.Button
    Friend WithEvents ArchitectureToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menubitcount As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ComputerNameToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menucomputername As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MemoryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AvailableRAMInstalledToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuRAM As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FreeRAMAvailableToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menufreeRAM As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox13 As System.Windows.Forms.GroupBox
    Friend WithEvents Button28 As System.Windows.Forms.Button
    Friend WithEvents ribbon_search As System.Windows.Forms.TextBox
    Friend WithEvents Button29 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Timer3 As System.Windows.Forms.Timer
    Friend WithEvents TabPage11 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox16 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox15 As System.Windows.Forms.GroupBox
    Friend WithEvents ribhistory As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox17 As System.Windows.Forms.GroupBox
    Friend WithEvents ribhistorysearch As System.Windows.Forms.ComboBox
    Friend WithEvents btnribfavourites As System.Windows.Forms.Button
    Friend WithEvents ribfavourite As System.Windows.Forms.ComboBox
    Friend WithEvents BlenderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HistoryFavouritesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HistoryToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuhistory As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents SearchBaseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuhistorysearch As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents FavouritesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menufavourties As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents ActivateSearchBarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddFavouritesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox19 As System.Windows.Forms.GroupBox
    Friend WithEvents Button30 As System.Windows.Forms.Button
    Friend WithEvents RerunFirstRunWizardToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox20 As System.Windows.Forms.GroupBox
    Friend WithEvents Button31 As System.Windows.Forms.Button
    Friend WithEvents SetHomePageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents TabControl3 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage12 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage13 As System.Windows.Forms.TabPage
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents TabControl2 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents GroupBox12 As System.Windows.Forms.GroupBox
    Friend WithEvents pinapp_2 As System.Windows.Forms.Button
    Friend WithEvents pinapp_1 As System.Windows.Forms.Button
    Friend WithEvents Button24 As System.Windows.Forms.Button
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents GroupBox14 As System.Windows.Forms.GroupBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents TabPage9 As System.Windows.Forms.TabPage
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Button25 As System.Windows.Forms.Button
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents WebBrowser1 As System.Windows.Forms.WebBrowser
    Friend WithEvents WebBrowser2a As System.Windows.Forms.WebBrowser
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents Tab1ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Tab2ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menudocumentype1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menudocumentype2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuencryptlevel1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuencry As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Tab2ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuencryptlevel2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Tab1ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuwebdomain1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Tab2ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuwebdomain2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Tab1ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menupagetitle1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Tab2ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menupagetitle2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Tab1ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuwebpath1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Tab2ToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents menuwebpath2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LeaderboardWebBrowser14Beta4Forkshaft4ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Build96ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Version1474ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EngineTridentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RadioButton4 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton3 As System.Windows.Forms.RadioButton
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Button32 As System.Windows.Forms.Button
    Friend WithEvents Button26 As System.Windows.Forms.Button
    Private WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Private WithEvents LineShape1 As Microsoft.VisualBasic.PowerPacks.LineShape
    Private WithEvents ShapeContainer2 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Private WithEvents LineShape2 As Microsoft.VisualBasic.PowerPacks.LineShape
    Private WithEvents LineShape3 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents AdvancedWebSettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangeSearchBaseEngineToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Button33 As System.Windows.Forms.Button
    Friend WithEvents GroupBox18 As System.Windows.Forms.GroupBox
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button34 As System.Windows.Forms.Button
    Friend WithEvents ContributorsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents LinkLabel2 As System.Windows.Forms.LinkLabel
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents DisplayStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ResizingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DisableToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EnableToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MainTitleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DisableToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EnableToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DefaultMaximizeMinimizeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DisableToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EnableToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox23 As System.Windows.Forms.GroupBox
    Friend WithEvents Button39 As System.Windows.Forms.Button
    Friend WithEvents GroupBox22 As System.Windows.Forms.GroupBox
    Friend WithEvents Button38 As System.Windows.Forms.Button
    Friend WithEvents Button37 As System.Windows.Forms.Button
    Friend WithEvents GroupBox21 As System.Windows.Forms.GroupBox
    Friend WithEvents Button36 As System.Windows.Forms.Button
    Friend WithEvents Button35 As System.Windows.Forms.Button
    Friend WithEvents Button40 As System.Windows.Forms.Button
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Webbrowser2 As Skybound.Gecko.GeckoWebBrowser

End Class
